If the bitflips num over mtd->bitflip_threshold the mtd_read_oob
will return -EUCLEAN and tags->ecc_result > YAFFS_ECC_RESULT_NO_ERROR. 
Then we will call yaffs_handle_chunk_error. 

From the code we can see if bitflips num over mtd->bitflip_threshold 
YAFFS will mark this block as gc,if bitflips num over mtd->bitflip_threshold
over three times we will mark this block as bad block. 

We define bad block is if erase or program failed we can 
mark this block as bad block. So it is reasonable just according to
the bitflips over mtd->bitflip_threshold over three times to judge 
the block as bad block.

This patch is suitalbe for all SLC/MLC NAND.
Here has two patches:
Add-block-refresh-handling-in-yaffs-core.patch is for yaffs source, based on yaffs2
mtd-nand-add-retirelimit-attribute.patch is for Linux MTD, based on Linux v3.18.
