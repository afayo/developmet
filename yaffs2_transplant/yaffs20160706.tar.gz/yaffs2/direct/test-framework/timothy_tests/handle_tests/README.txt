handle_tests.c opens and closes random handles, in an effot to stress test yaffs.

Command line options:
	No commands.

compile command: make
run command: ./handle_test
